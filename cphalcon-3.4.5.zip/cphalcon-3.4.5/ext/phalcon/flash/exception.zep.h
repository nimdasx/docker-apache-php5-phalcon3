
extern zend_class_entry *phalcon_flash_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Flash_Exception);

