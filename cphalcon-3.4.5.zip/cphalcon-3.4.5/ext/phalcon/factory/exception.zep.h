
extern zend_class_entry *phalcon_factory_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Factory_Exception);

